
#              Utilities for processing egg table files

    require 'csv.pl';

#   READ_HEADER  --  Read header from file and set global status variables

    sub read_header
    {
        local($file) = @_;
        local ($l, @f);

        while ($l = <$file>) {
            chop($l);
            @f = &csv($l);
#           print(join(',', @f) . "\n");

            #   Type 10 records: protocol description

            if ($f[0] == 10) {
                if ($f[1] == 1) {
                    $samp_rec = $f[2];
                } elsif ($f[1] == 2) {
                    $sec_rec = $f[2];
                } elsif ($f[1] == 3) {
                    $rec_pkt = $f[2];
                } elsif ($f[1] == 4) {
                    $trialsz = $f[2];
                }
            }

            #   Type 11 records: file content description

            elsif ($f[0] == 11) {
                if ($f[1] == 1) {
                    $numEggs = $f[2];
                } elsif ($f[1] == 2) {
                    $startTime = $f[2];
                } elsif ($f[1] == 3) {
                    $endTime = $f[2];
                } elsif ($f[1] == 4) {
                    $tableSeconds = $f[2];
                }
            }

            #   Type 12 record: Egg IDs correponding to table columns

            elsif ($f[0] == 12) {
                for ($i = 3; $i <= $#f; $i++) {
                    $eggNumbers[$i - 3] = $f[$i];
                }
                last;                     # Bail out to data record processing code
            }

        }
    }

#   DUMP_HEADER  --  Dump values from file header

    sub dump_header
    {
        local($i);

        print("Samples per record: $samp_rec\n");
        print("Seconds per record: $sec_rec\n");
        print("Records per packet: $rec_pkt\n");
        print("Trial size: $trialsz\n");
        print("Eggs reporting: $numEggs\n");
        print("Start time: $startTime\n");
        print("End time:   $endTime\n");
        print("Seconds of data: $tableSeconds\n");
        print("Egg IDs by column:\n");
        for ($i = 0; $i <= $#eggNumbers; $i++) {
            printf("  %4d: %4d\n", $i, $eggNumbers[$i]);
        }
    }

#   READ_TRIAL  --  Read one trial data record.  The result
#                   is an array, the first element of which is
#                   the Unix date and time of the trial,
#                   followed by $numEggs items representing
#                   the results for the eggs in the order of
#                   the @eggNumbers array.  Missing data for
#                   an egg is denoted by a blank (note--not zero!)
#                   result cell.  An array with a time field of
#                   -1 is returned when end of file is encountered.

    sub read_trial
    {
        local($file) = @_;
        local ($l, @f, @r);

        if ($l = <$file>) {
            chop($l);
            @f = &csv($l);

            if ($f[0] == 13) {
                $r[0] = $f[1];
                for ($i = 0; $i < $numEggs; $i++) {
                    $r[$i + 1] = $f[$i + 3];
                }
            } else {
                next;
            }
            return @r;
        } else {
#print("EOF\n");
            $r[0] = -1;
            return @r;
        }
    }

if (0) {
    open(IFILE, "<19980806.csv");

    &read_header(IFILE);
    &dump_header();

    while (@d = &read_trial(IFILE)) {
        if ($d[0] == -1) {
            last;
        }
        if (($d[0] % 1000) == 0) {
            print(join(',', @d) . "\n");
        }
    }
}

1;
