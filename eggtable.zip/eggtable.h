/*

	Egg data table definitions

*/

typedef unsigned char eggTrial;

#define MISSING_DATA	255	      /* Value denoting missing data from egg */

typedef struct {
    unsigned int numEggs;	      /* Number of eggs in table */
    unsigned int *eggNumbers;	      /* Egg numbers corresponding to indices */
    unsigned int samp_rec;	      /* Number of samples per record */
    unsigned int sec_rec;	      /* Number of seconds per record */
    unsigned int rec_pkt;	      /* Number of records per packet */
    unsigned int trialsz;	      /* Number of bits per trial */
    unsigned long startTime;	      /* Time of first data in table */
    unsigned long tableSeconds;       /* Number of seconds of data in table */
    eggTrial **trialTable;	      /* Array of data from eggs */
} eggTable;

/*  Function prototypes.  */

extern eggTable *buildEggTable(int nfiles, char **files,
			       unsigned long startTime, unsigned long endTime);
extern void dumpEggTable(FILE *f, eggTable *et);
extern void destroyEggTable(eggTable *et);
