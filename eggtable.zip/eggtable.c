/*

	Functions in this file scan data in one or more
	basket data files and produce an in-memory table
	of egg data indexed by seconds and egg index.
	Missing data is indicated by a flag representing
	an impossible trial result.

*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "basketin.h"
#include "eggtable.h"

#ifdef DEBUG
static void dumpPacket(FILE *out, basketRecord *r)
{
    char edtime[64];
    int i, j;

    fprintf(out, "%d records from egg %d.\n",
	    r->numrec, r->eggid);

    for (j = 0; j < r->numrec; j++) {
        strftime(edtime, sizeof edtime, "%Y-%m-%d %H:%M:%S",
	    gmtime((time_t *) &r->records[j].timestamp));
        fprintf(out, "  %s ", edtime, r->records[j].timestamp);
	for (i = 0; i < r->samp_rec; i++) {
            fprintf(out, " %3d", r->records[j].trials[i]);
	}
        fprintf(out, "\n");
    }
}
#endif

/*  dumpEggTable  --  Dump an eggTable to the specified file
		      in primate-readable format.  */

void dumpEggTable(FILE *f, eggTable *et)
{
    char edtime[64];
    int i, j;
    unsigned long t;

    strftime(edtime, sizeof edtime, "%Y-%m-%d %H:%M:%S",
	gmtime((time_t *) &et->startTime));
    fprintf(f, "Start time: %s\n", edtime);
    fprintf(f, "Seconds of data: %lu\n", et->tableSeconds);
    fprintf(f, "Samples per record: %d\n", et->samp_rec);
    fprintf(f, "Seconds per record: %d\n", et->sec_rec);
    fprintf(f, "Records per packet: %d\n", et->rec_pkt);
    fprintf(f, "Trial size:         %d\n", et->trialsz);
    fprintf(f, "Eggs reporting:     %d\n", et->numEggs);

    /*	Generate the column headings for the eggs.  */

    fprintf(f, "                     ");
    for (i = 0; i < et->numEggs; i++) {
        fprintf(f, " %3d", et->eggNumbers[i]);
    }
    fprintf(f, "\n");

    /*	Output the trial data, arranged in columns by egg.  */

    t = et->startTime;
    for (i = 0; i < et->tableSeconds; i++) {
        strftime(edtime, sizeof edtime, "%Y-%m-%d %H:%M:%S",
	    gmtime((time_t *) &t));
	t++;
        fprintf(f, "%s  ", edtime);
	for (j = 0; j < et->numEggs; j++) {
	    if (et->trialTable[i][j] == MISSING_DATA) {
                fprintf(f, "    ");
	    } else {
                fprintf(f, " %3d", et->trialTable[i][j]);
	    }
	}
        fprintf(f, "\n");
    }
}

/*  destroyEggTable  --  Destroy an in-memory EggTable,
			 releasing all storage.  */

void destroyEggTable(eggTable *et)
{
    if (et->eggNumbers != NULL) {
	free(et->eggNumbers);
    }
    if (et->trialTable != NULL) {
	free(et->trialTable[0]);      /* This points to start of data array */
	free(et->trialTable);	      /* Free the row pointer vector */
    }
    free(et);
}

/*  buildEggTable  --  Creates an eggTable from the data in
		       a list of file names, for a specified
		       period of time.	If both startTime and
		       endTime are zero, all data in all the
		       files is returned.  NULL is returned
		       in case of error.  */

#define INITIAL_EGGS	100

eggTable *buildEggTable(int nfiles, char **files,
			unsigned long startTime, unsigned long endTime)
{
    int i, n, neggs, meggs = INITIAL_EGGS, s;
    unsigned long startSecond, endSecond;
    FILE *fp;
    basketRecord br, obr;
    int *eggList;
    eggTable *et = NULL;
#ifdef DEBUG
    long sampstored = 0;
#endif

    if (endTime == 0) {
	endTime = 0xFFFFFFFF;
    }

    /*	Pass 1.  Scan the files and determine how many eggs
		 are present in the data and the time span
		 of data present (within the specified time
		 range, if any).  */

    neggs = 0;
    n = 0;
    startSecond = 0xFFFFFFFF;
    endSecond = 0;
    eggList = malloc(meggs * (sizeof(int)));
    if (eggList == NULL) {
        fprintf(stderr, "buildEggTable: cannot allocate eggList.\n");
    }
    for (i = 0; i < nfiles; i++) {
        fp = fopen(files[i], "r");
	if (fp == NULL) {
            fprintf(stderr, "buildEggTable: cannot open file %d, %s\n",
		i, files[i]);
	    free(eggList);
	    return NULL;
	}

	while ((s = basketReadNextRecord(fp, &br)) == 0) {
	    int e;

	    if (n > 0) {
                /* Verify protocol didn't change during data set. */
		if (br.samp_rec != obr.samp_rec ||
		    br.sec_rec != obr.sec_rec ||
		    br.rec_pkt != obr.rec_pkt ||
		    br.trialsz != obr.trialsz) {
                    fprintf(stderr, "buildEggTable: Protocol is inconsistent across data in file %s, record %d.\n", files[i], n);
#ifdef DEBUG
fprintf(stderr, "br = ");
dumpPacket(stderr, &br);
fprintf(stderr, "\nobr = ");
dumpPacket(stderr, &obr);
#endif
		    free(eggList);
		    return NULL;
		}
	    }
/*		memcpy(&obr, &br, sizeof(basketRecord)); */
	    obr = br;
	    n++;

	    /* Verify if any of the samples in this packet are
	       within the requested time range.  We do this before
               checking for a new egg since there's no reason to
               reserve space for an egg which didn't contribute
	       any data to the requested range. */

	    if (br.numrec == 0 ||
		((br.records[br.numrec - 1].timestamp +
		    (br.sec_rec - 1)) < startTime) ||
		(br.records[0].timestamp > endTime)) {
		continue;
	    }

	    /* Determine whether this is a new egg.  If so, add it
	       to the egg list and increment the number of eggs
	       present in the data set. */

	    for (e = 0; e < neggs; e++) {
		if (br.eggid == eggList[e]) {
		    break;
		}
	    }
	    if (e >= neggs) {
		if (neggs >= meggs) {
		    meggs += INITIAL_EGGS;
		    eggList = (int *) realloc(eggList, meggs * (sizeof(int)));
		    if (eggList == NULL) {
                        fprintf(stderr, "buildEggTable: cannot re-allocate eggList for %d eggs.\n", meggs);
		    }
		}
		eggList[neggs++] = br.eggid;
	    }

	    /* Now step through trial times in this packet,
	       examining only those within the requested range,
	       if any, and update the trial time extrema if
	       any trial expands them. */

	    for (e = 0; e < br.numrec; e++) {
		unsigned long t = br.records[e].timestamp;
		int j;

		for (j = 0; j < br.samp_rec; j++) {
		    if (t >= startTime && t <= endTime) {
			if (t < startSecond) {
			    startSecond = t;
			}
			if (t > endSecond) {
			    endSecond = t;
			}
		    }
		    t += br.sec_rec / br.samp_rec;
		}
	    }
	}
	fclose(fp);
	if (s != EOF) {
            fprintf(stderr, "buildEggTable: error %d from basketReadNextRecord of file %s\n",
		s, files[i]);
	    free(eggList);
	    return NULL;
	}
    }

    /*  Sort the egg number list by egg ID.  This isn't strictly
        necessary, but it's nice to the caller.  This is a
        ghastly bubble sort, but we're unlikely to have enough
	eggs in the near future to justify the complexity of
	something more elaborate.  */

    for (i = 0; i < neggs; i++) {
	int j;

	for (j = i + 1; j < neggs; j++) {
	    if (eggList[i] > eggList[j]) {
		int h = eggList[i];

		eggList[i] = eggList[j];
		eggList[j] = h;
	    }
	}
    }

#ifdef DEBUG
    printf("Data from %d eggs found:\n", neggs);
    for (i = 0; i < neggs; i++) {
        printf("  %4d:  %d\n", i, eggList[i]);
    }
    printf("First sample: %s", asctime(gmtime((time_t *) &startSecond)));
    printf("Last sample:  %s", asctime(gmtime((time_t *) &endSecond)));
#endif

    /*	Interphase processing.	Allocate data for the structure
	and the arrays it points to, and initialise global
	properties of the structure.  */

    et = malloc(sizeof(eggTable));
    if (et == NULL) {
        fprintf(stderr, "buildEggTable: cannot allocate eggTable.\n");
	free(eggList);
	return NULL;
    }
    et->numEggs = neggs;
    et->eggNumbers = NULL;
    if (neggs > 0) {
	et->eggNumbers = malloc(neggs * sizeof(int));
	if (et->eggNumbers == NULL) {
            fprintf(stderr, "buildEggTable: cannot allocate eggNumber list.\n");
	    free(eggList);
	    free(et);
	    return NULL;
	}
    }

    /* Transfer egg list accumulated during scan to eggNumbers
       array in result packet. */

    memcpy(et->eggNumbers, eggList, neggs * sizeof(int));

    /* Store database-wide protocol values. */
    et->samp_rec = br.samp_rec;
    et->sec_rec = br.sec_rec;
    et->rec_pkt = br.rec_pkt;
    et->trialsz = br.trialsz;
    et->startTime = startSecond;

    /* If any data were selected, allocate the result table
       and initialise it to the value which signifies missing
       data. */
    if (startSecond > endSecond) {
	et->tableSeconds = 0;
	et->trialTable = NULL;
    } else {
	eggTrial *etp;
	int secidx, eggidx;

	et->tableSeconds = (endSecond - startSecond) + 1;
	et->trialTable = malloc(et->tableSeconds * sizeof(eggTrial *));
	if (et->trialTable == NULL) {
            fprintf(stderr, "buildEggTable: cannot allocate eggTrial pointer table.\n");
	    if (et->eggNumbers != NULL) {
		free(et->eggNumbers);
	    }
	    free(et);
	    return NULL;
	}
	et->trialTable[0] = malloc(et->tableSeconds * et->numEggs * sizeof(eggTrial));
	if (et->trialTable[0] == NULL) {
            fprintf(stderr, "buildEggTable: cannot allocate eggTrial data array.\n");
	    if (et->eggNumbers != NULL) {
		free(et->eggNumbers);
	    }
	    free(et->trialTable);
	    free(et);
	    return NULL;
	}

        /* Okay, at long last everything's allocated.  Now plug
	   in the row pointers in trialTable and initialise the
	   data array to missing data. */

	etp = et->trialTable[0];
	for (secidx = 0; secidx < et->tableSeconds; secidx++) {
	    et->trialTable[secidx] = etp;
	    for (eggidx = 0; eggidx < et->numEggs; eggidx++) {
		*etp++ = MISSING_DATA;
	    }
	}
    }
    /* From now on, it's safe to call destroyEggTable to
       discard et, should an error occur. */

    /*	Pass 2:  Scan the data again and enter in-range
		 trials into the data array, indexed by egg
		 index in eggNumbers and seconds elapsed
		 since startTime.  */

    n = 0;
    for (i = 0; i < nfiles; i++) {
        fp = fopen(files[i], "r");
	if (fp == NULL) {
            fprintf(stderr, "buildEggTable: cannot open file %d, %s\n",
		i, files[i]);
	    free(eggList);
	    return NULL;
	}

	while ((s = basketReadNextRecord(fp, &br)) == 0) {
	    int e, eggdex;

#ifdef DEBUG
	    if (n > 0) {
                /* Verify protocol didn't change during data set. */
		if (br.samp_rec != obr.samp_rec ||
		    br.sec_rec != obr.sec_rec ||
		    br.rec_pkt != obr.rec_pkt ||
		    br.trialsz != obr.trialsz) {
                    fprintf(stderr, "buildEggTable: Protocol is inconsistent across data in file %s, record %d.\n", files[i], n);
#ifdef DEBUG
fprintf(stderr, "br = ");
dumpPacket(stderr, &br);
fprintf(stderr, "\nobr = ");
dumpPacket(stderr, &obr);
#endif
		    free(eggList);
		    return NULL;
		}
	    }
	    obr = br;
#endif
	    n++;

            /* Find this packet's egg index in the eggNumbers array. */

	    for (eggdex = 0; eggdex < et->numEggs; eggdex++) {
		if (et->eggNumbers[eggdex] == br.eggid) {
		    break;
		}
	    }
#ifdef DEBUG
	    if (eggdex >= et->numEggs) {
                fprintf(stderr, "buildEggTable: WHAT!?!?!?  Can't find egg %d in eggNumbers array?\n", br.eggid);
	    }
#endif

	    /* Now step through trials in this packet,
	       copying any within the selected time range
	       into their slots in the trial data array.
	       Missing data, indicated by a trial value
	       of EGG_MISSING_DATA, is not stored, leaving
	       our own MISSING_DATA sentinel in the slot. */

	    for (e = 0; e < br.numrec; e++) {
		unsigned long t = br.records[e].timestamp;
		int j;

		for (j = 0; j < br.samp_rec; j++) {
		    if (t >= startSecond && t <= endSecond) {
#ifdef DEBUG
			sampstored++;
			if (et->trialTable[t - startSecond][eggdex] !=
			    MISSING_DATA) {
                            fprintf(stderr, "buildEggTable: duplicate data for egg %d at %s",
				br.eggid, asctime(gmtime((time_t *) &t)));
			}
#endif
			if (br.records[e].trials[j] != EGG_MISSING_DATA) {
			    et->trialTable[t - startSecond][eggdex] =
			    br.records[e].trials[j];
			}
		    }
		    t += br.sec_rec / br.samp_rec;
		}
	    }
	}
	fclose(fp);
	if (s != EOF) {
            fprintf(stderr, "buildEggTable: error %d from basketReadNextRecord of file %s\n",
		s, files[i]);
	    free(eggList);
	    return NULL;
	}
    }

#ifdef DEBUG
    fprintf(stderr, "%ld samples stored into %lu possible slots.\n",
	sampstored, et->tableSeconds * et->numEggs);
#endif

    return et;
}

#ifdef TEST
int main()
{
    eggTable *et;
    char *filelist[] = {
                                "/usr0/data/basketdata.19980804",
                            "basketdata.19980801",
                            "basketdata.small"
		       };

    et = buildEggTable(1, filelist, 0, 0);
    if (et != NULL) {
	dumpEggTable(stdout, et);
	destroyEggTable(et);
    }
    return 0;
}
#endif
