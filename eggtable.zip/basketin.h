/*

	      Read basket database file  --  definitions

*/

#define BASKETIN_MAXSAMP_REC	 10   /* Maximum samples/record */
#define BASKETIN_MAXREC_PKT	 60   /* Maximum number of records per packet */
#define EGG_MISSING_DATA	254   /* Sentinel used by the egg
					 to denote missing samples
					 in the trials[] array. */

typedef unsigned char trial;	      /* Data type of trial results. */

typedef struct	{
  unsigned long timestamp;	      /* Seconds since January 1, 1970 00:00 UTC */
  trial trials[BASKETIN_MAXSAMP_REC]; /* Trial values */
} trialRecord;

/*  Basket data record packet.	Note that in this packet trialsz
    is declared as an unsigned short, while in the actual egg/basket
    protocol it is declared as "trial"--an unsigned char.  Since we
    include a pad byte in the basket data file, this allows for
    transparent growth in the analysis programs if we decide to
    increase the number of trials beyond 255.  A future version of
    basketin would, upon discovering a trialsz >= 256, return
    records with an appropriately sized trial item.  */

typedef struct {
  unsigned short type;		      /* Packet type */
  unsigned short pktsize;	      /* Number of bytes in packet */
  unsigned short eggid; 	      /* Identifying number for device */
  unsigned short samp_rec;	      /* Number of samples per record */
  unsigned short sec_rec;	      /* Number of seconds per record */
  unsigned short rec_pkt;	      /* Number of records per packet */
  unsigned short trialsz;	      /* Number of bits per trial */
  unsigned short numrec;	      /* Number of valid records */
  trialRecord records[BASKETIN_MAXREC_PKT]; /* Trial records */
} basketRecord;

/*  Function prototypes.  */

extern int basketReadNextRecord(FILE *fp, basketRecord *dst);

/*  basketReadNextRecord error codes  */

#define BASKETIN_ERR_BADTYPE	-2    /* Packet in file is not a data packet */
#define BASKETIN_ERR_TRUNCATED	-3    /* Record truncated: premature end of file */
#define BASKETIN_ERR_CRC	-4    /* Packet CRC incorrect or terminator missing */
#define BASKETIN_ERR_LENGTH	-5    /* Length in packet != actual decode length */
#define BASKETIN_ERR_NUMREC	-6    /* Number of records in packet exceeds
					 BASKETIN_MAXREC_PKT above. */
#define BASKETIN_ERR_NUMSAMP	-7    /* Number of samples per record exceeds
					 BASKETIN_MAXSAMP_REC above. */
#define BASKETIN_ERR_RECPACKET	-8    /* Records per packet (numrec) exceeds
                                         packet's own maximum (rec_pkt). */
