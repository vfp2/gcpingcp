/*

	    Basket data translator

    This program assembles a time-aligned table of samples for
    a selected list of eggs and time span (using eggtable.c),
    then outputs it in an easily-processed CSV form.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <time.h>
#include <limits.h>

#include "eggtable.h"

#define FALSE	0
#define TRUE	1

static unsigned long s_time = 0, e_time = 0; /* Start and end times of extract */
static int brief = FALSE;             /* Don't interpret times in data records to save space */

/*  PARSETIME  --  Parse a date and time specification and
		   return a Unix time value.  A result of 0xFFFFFFFF
		   indicates a syntax error in the date and time.
		   The time is specified as:

			yyyy-mm-dd-hh:mm:ss

		    In fact, any delimiters whatsoever may be used.
		    If seconds are omitted, they default to zero.  */

static unsigned long parsetime(char *s)
{
    struct tm t;
    char c;

    t.tm_sec = 0;
    if (sscanf(s, "%u%c%u%c%u%c%u%c%u%c%u", &t.tm_year, &c, &t.tm_mon, &c,
		    &t.tm_mday, &c, &t.tm_hour, &c, &t.tm_min, &c, &t.tm_sec) < 9) {
	return 0xFFFFFFFF;
    }
    t.tm_mon--;
    t.tm_year -= 1900;
    if (t.tm_mon < 0 || t.tm_mon > 11 || t.tm_mday > 31 || t.tm_hour > 23 || t.tm_min > 59) {
	return 0xFFFFFFFF;
    }
    t.tm_isdst = 0;
    return (unsigned long) mktime(&t);
}

/*  EGGTABLE_TO_CSV  --  Output data from an egg table as a CSV file.  */

static void eggTable_to_CSV(FILE *f, eggTable *et)
{
    char edtime[64];
    int i, j;
    unsigned long t;

    /*	Output protocol properties as type 10 records.	The
	second field identifies the item, the third gives
	its values.  The fourth field serves as a label.  */

    fprintf(f, "10,1,%d,\"Samples per record\"\n", et->samp_rec);
    fprintf(f, "10,2,%d,\"Seconds per record\"\n", et->sec_rec);
    fprintf(f, "10,3,%d,\"Records per packet\"\n", et->rec_pkt);
    fprintf(f, "10,4,%d,\"Trial size\"\n", et->trialsz);

    /*	Type 11 records indicate the properties of the file
	content which follows: number of eggs reporting
	and the time span covered.  */

    fprintf(f, "11,1,%d,\"Eggs reporting\"\n", et->numEggs);
    strftime(edtime, sizeof edtime, "%Y-%m-%d %H:%M:%S",
	gmtime((time_t *) &et->startTime));
    fprintf(f, "11,2,%d,\"Start time\",%s\n", et->startTime, edtime);
    t = (et->startTime + et->tableSeconds) - 1;
    strftime(edtime, sizeof edtime, "%Y-%m-%d %H:%M:%S",
	gmtime((time_t *) &t));
    fprintf(f, "11,3,%d,\"End time\",%s\n", t, edtime);
    fprintf(f, "11,4,%d,\"Seconds of data\"\n", et->tableSeconds);


    /*	A type 12 record contains column headings for the data
	which follow.  Egg data columns are labeled with the egg
	number.  */

    fprintf(f, "12,\"gmtime\",%s", brief ? "" : "\"Date/Time\"");
    for (i = 0; i < et->numEggs; i++) {
        fprintf(f, ",%d", et->eggNumbers[i]);
    }
    fprintf(f, "\n");

    /*	Output the trial data as type 13 records, arranging
	egg data in the corresponding columns.	Missing data
	results in a blank field for the egg at that time.  */

    t = et->startTime;
    for (i = 0; i < et->tableSeconds; i++) {
	if (brief) {
	    edtime[0] = 0;
	} else {
            strftime(edtime, sizeof edtime, "%Y-%m-%d %H:%M:%S",
		gmtime((time_t *) &t));
	}
        fprintf(f, "13,%d,%s", t, edtime);
	for (j = 0; j < et->numEggs; j++) {
	    if (et->trialTable[i][j] == MISSING_DATA) {
                fprintf(f, ",");
	    } else {
                fprintf(f, ",%d", et->trialTable[i][j]);
	    }
	}
        fprintf(f, "\n");
	t++;
    }
}

/*  USAGE  --  Print how-to-call information.  */

static void usage()
{
    fprintf(stderr, "basketran  --  Basket data translator.\n");
    fprintf(stderr, "\n");
    fprintf(stderr, "Usage: basketran [options] [input_file ...]\n");
    fprintf(stderr, "Defaults   Options\n");
    fprintf(stderr, "           -B         Brief: don\'t interpret date/time in data records\n");
    fprintf(stderr, "           -ESyyyy-mm-dd:hh-mm-ss  Extract records starting at given time\n");
    fprintf(stderr, "           -EEyyyy-mm-dd:hh-mm-ss  Extract records ending at given time\n");
    fprintf(stderr, "           -U         Print this message\n");
    fprintf(stderr, "\n");
    fprintf(stderr, "by John Walker\n");
    fprintf(stderr, "http://www.fourmilab.ch/\n");
}

/*  Main program.  */

int main(int argc, char *argv[])
{
    FILE *fp = stdin;
    int i, n = 0, first = TRUE;
    eggTable *et;

    putenv("TZ=UTC0");                /* So mktime() will work in UTC */
    
    for (i = 1; i < argc; i++) {
	char *op, opt, *zop;

	op = argv[i];
        if (*op == '-') {
	    opt = *(++op);
	    if (islower(opt)) {
		opt = toupper(opt);
	    }

	    switch (opt) {

                case 'B':             /* -B  Brief: don't interpret date and time in data records  */
		    brief = TRUE;
		    break;

                case 'E':             /* -E[se]  Set start or end time of extract  */
		    opt = *(++op);
		    if (islower(opt)) {
			opt = toupper(opt);
		    }
                    if (opt == 'S' || opt == 'B') {
			s_time = parsetime(op + 1);
#ifdef DEBUG
fprintf(stderr, "Start time: %s", asctime(gmtime((time_t *) &s_time)));
#endif
                    } else if (opt == 'E') {
			e_time = parsetime(op + 1);
#ifdef DEBUG
fprintf(stderr, "End time: %s", asctime(gmtime((time_t *) &e_time)));
#endif
		    } else {
                        fprintf(stderr, "Invalid -E option start/end specification.  Use S or E.\n");
			usage();
			return 2;
		    }
		    if (((long) s_time) < 0 || ((long) e_time) < 0) {
                        fprintf(stderr, "Badly formatted date/time in -E option specification.\n");
			usage();
			return 2;
		    }
		    break;

                case 'U':             /* -U  Print how to call information */
                case '?':
		    usage();
		    return 0;
	    }
	} else {
	    break;
	}
    }

    /* At this point argv[i] theoretically points to the first
       of (argc - i) file names. */

/*printf("%d data files.\n", argc - i);*/
    et = buildEggTable(argc - i, argv + i, s_time, e_time);

    if (et == NULL) {
        fprintf(stderr, "Error building egg data table.\n");
	return 2;
    }

    eggTable_to_CSV(stdout, et);

    destroyEggTable(et);

    return 0;
}
