/*

		      Dump basket database file

*/

#include <stdio.h>
#include <time.h>

#include "basketin.h"

int main(int argc, char *argv[])
{
    FILE *fp;
    basketRecord r;
    int i, j, pktno = 0;
    char edtime[64];

    if (argc != 2) {
        fprintf(stderr, "Usage: dumpbasket basket_data_file\n");
	return 2;
    }

    if ((fp = fopen(argv[1], "r")) == NULL) {
        fprintf(stderr, "%s: cannot open basket data file %s\n",
	    argv[0], argv[1]);
	return 1;
    }

    while (1) {
	long pos = ftell(fp);
	int s = basketReadNextRecord(fp, &r);

	if (s == EOF) {
	    break;
	}
	if (s != 0) {
	    fprintf(stderr,
                "%s: Error %d reading basket data at file position %ld.\n",
		argv[0], s, pos);
	    return s;
	}

        printf("%s packet %d: %d records from egg %d.\n",
		argv[1], ++pktno, r.numrec, r.eggid);

	for (j = 0; j < r.numrec; j++) {
            strftime(edtime, sizeof edtime, "%Y-%m-%d %H:%M:%S",
		gmtime((time_t *) &r.records[j].timestamp));
            printf("  %s ", edtime);
	    for (i = 0; i < r.samp_rec; i++) {
                printf(" %3d", r.records[j].trials[i]);
	    }
            printf("\n");
	}
    }
    fclose(fp);

    return 0;
}
